from project.robot import Robot
import unittest


class TestRobot(unittest.TestCase):
    def setUp(self) -> None:
        self.robot = Robot('442', 'Military', 100, 50.5)
        self.ALLOWED_CATEGORIES = ['Military', 'Education', 'Entertainment', 'Humanoids']
        self.PRICE_INCREMENT = 1.5

    def test_init(self):
        self.assertEqual(self.robot.robot_id, '442')
        self.assertEqual(self.robot.category, 'Military')
        self.assertEqual(self.robot.available_capacity, 100)
        self.assertEqual(self.robot.price, 50.5)
        self.assertEqual(self.robot.hardware_upgrades, [])
        self.assertEqual(self.robot.software_updates, [])

    def test_category_invalid(self):
        with self.assertRaises(ValueError) as text:
            self.robot.category = 'Steam'
        self.assertEqual(str(text.exception), f"Category should be one of '{self.ALLOWED_CATEGORIES}'")

    def test_valid_category(self):
        self.robot.category = 'Education'
        self.assertEqual(self.robot.category, 'Education')

    def test_price(self):
        self.robot.price = 40
        self.assertEqual(self.robot.price, 40)

        with self.assertRaises(ValueError) as context:
            self.robot.price = -50

        self.assertEqual(str(context.exception), "Price cannot be negative!")

    def test_upgrade(self):
        result = self.robot.upgrade('SSD', 20.5)
        self.assertEqual(result, f'Robot {self.robot.robot_id} was upgraded with SSD.')
        self.assertEqual(self.robot.upgrade('SSD', 20.5), f"Robot {self.robot.robot_id} was not upgraded.")

    def test_update(self):
        result = self.robot.update(2.2, 20)
        self.assertEqual(result, f'Robot {self.robot.robot_id} was updated to version 2.2.')
        self.assertEqual(self.robot.available_capacity, 80)

        self.assertEqual(self.robot.update(2.2, 110), f"Robot {self.robot.robot_id} was not updated.")
        self.assertEqual(self.robot.update(1.2, 20), f"Robot {self.robot.robot_id} was not updated.")

    def test_gt_(self):
        self.assertEqual(self.robot.__gt__(Robot('552', 'Military', 50, 250.5)), f'Robot with ID {self.robot.robot_id}'
                                                                                 f' is cheaper than Robot with ID 552.')
        self.assertEqual(self.robot.__gt__(Robot('552', 'Military', 50, 50.5)), f'Robot with ID {self.robot.robot_id}'
                                                                                 f' costs equal to Robot with ID 552.')
        self.assertEqual(self.robot.__gt__(Robot('552', 'Military', 50, 10.5)), f'Robot with ID {self.robot.robot_id}'
                                                                                f' is more expensive than Robot with ID 552.')
